#!/bin/bash

cp ./createTable.sh ~/sharedFolder/
cp ./createTable.sql ~/sharedFolder/
docker exec -t tsDB sudo /home/machbase/sharedVolume/createTable.sh &

sleep 10

docker cp ./MWA.conf tsDB:/home/machbase/machbase/webadmin/flask/MWA.conf
cp ./restartMWA.sh ~/sharedFolder/
docker exec -t tsDB sudo /home/machbase/sharedVolume/restartMWA.sh &

