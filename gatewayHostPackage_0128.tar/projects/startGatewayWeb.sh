#!/bin/bash
/home/admin/projects/run.sh
